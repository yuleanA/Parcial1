import React, { useState } from "react";
import ReserveError from "./components/ReserveError";

function App() {
  const [reservations, setReservations] = useState([]);
  const [name, setName] = useState("");
  const [msg, setMsg] = useState("");
  const [row, setRow] = useState("");
  const [seat, setSeat] = useState("");

  const handleNameChange = (event) => {
    setName(event.target.value.toUpperCase());
  };

  const handleRowChange = (event) => {
    setRow(event.target.value.toUpperCase());
  };

  const handleSeatChange = (event) => {
    setSeat(event.target.value.toUpperCase());
  };

  const handleReserve = (event) => {
    event.preventDefault();
    // Find if the seat and the row is not occupied
    let found = reservations.find((x) => x.row === row && x.seat === seat);

    if (!found) {
      setReservations([...reservations, { name, row, seat }]);
      setName("");
      setRow("");
      setSeat("");
      setMsg("");
    } else {
      // si quieres cambia esto por alert y ya
      setMsg("La fila y el asiento está ocupado");
    }
  };

  return (
    <div>
      <h1>Reserve Asientos</h1>
      <form onSubmit={handleReserve}>
        <label>
          Nombre:
          <input type="text" value={name} onChange={handleNameChange} />
        </label>
        <br />
        <label>
          Fila:
          <input type="text" value={row} onChange={handleRowChange} />
        </label>
        <br />
        <label>
          Asiento:
          <input type="text" value={seat} onChange={handleSeatChange} />
        </label>
        <br />
        <button type="submit">Reservar</button>
      </form>
      <br />
      <ReserveError msg={msg} />
      <h2>Reservas:</h2>
      <ul>
        {reservations.map((reservation, index) => (
          <li key={index}>
            {reservation.name} - Fila: {reservation.row}, Asiento:{" "}
            {reservation.seat}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
