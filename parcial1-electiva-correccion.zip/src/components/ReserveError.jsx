import React from "react";

function ReserveError({ msg }) {
  return (
    <>
      <h5>{msg ? "Error: " + msg : ""}</h5>
    </>
  );
}

export default ReserveError;
